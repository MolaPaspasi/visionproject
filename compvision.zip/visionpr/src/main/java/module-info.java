module org.example.visionpr {
    requires javafx.controls;
    requires javafx.fxml;
    requires opencv;
    requires java.desktop;


    opens org.example.visionpr to javafx.fxml;
    exports org.example.visionpr;
}