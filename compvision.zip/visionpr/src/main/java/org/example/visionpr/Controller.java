package org.example.visionpr;


import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;


public class Controller{
    @FXML
    private Button browseButton;

    @FXML
    private ImageView originalImageView;

    @FXML
    private ChoiceBox<String> directionChoiceBox;

    @FXML
    private ImageView processedImageView;

    @FXML
    private TextField sigmaTextField;

    @FXML
    private TextField kernelSizeField;
    @FXML
    private TextField rotationAngleField;

    @FXML
    private ChoiceBox<String> rotationInterpolationChoiceBox;
    @FXML
    private TextField kernelSizeField2;

    @FXML
    private TextField kernelSizeFieldAverage;

    private Mat originalMat;
    private Mat processedMat;

    @FXML
    private Button clearOutputButton;

    static {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
    }

    @FXML
    private TextField scaleFactorField;

    @FXML
    private ChoiceBox<String> interpolationChoiceBox;

    @FXML
    public void initialize() {
        browseButton.setOnAction(e -> browseImage());
        directionChoiceBox.getItems().addAll("Horizontal", "Vertical", "Both");
        directionChoiceBox.setValue("Both");

        interpolationChoiceBox.getItems().addAll("Nearest Neighbor", "Bilinear");
        interpolationChoiceBox.setValue("Nearest Neighbor");

        rotationInterpolationChoiceBox.getItems().addAll("Nearest Neighbor", "Bilinear");
        rotationInterpolationChoiceBox.setValue("Nearest Neighbor");
    }

    @FXML
    private void generateGrayRectangles() {
        Mat image = new Mat(512, 512, CvType.CV_8UC3, new Scalar(0, 0, 0));

        Imgproc.rectangle(image,
                new Point(0, 0),
                new Point(512, 100),
                new Scalar(50, 50, 50),
                -1
        );

        Imgproc.rectangle(image,
                new Point(0, 100),
                new Point(512, 200),
                new Scalar(100, 100, 100),
                -1
        );

        Imgproc.rectangle(image,
                new Point(0, 200),
                new Point(512, 300),
                new Scalar(150, 150, 150),
                -1
        );

        Imgproc.rectangle(image,
                new Point(300, 300),
                new Point(400, 400),
                new Scalar(255, 255, 255),
                -1
        );

        processedMat = image;

        processedImageView.setImage(matToImage(processedMat));

        saveGeneratedImage();
    }

    private void saveGeneratedImage() {
        if (processedMat != null) {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Gray Rectangles Image");
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Image Files", "*.png")
            );

            File file = fileChooser.showSaveDialog(null);
            if (file != null) {
                Imgcodecs.imwrite(file.getAbsolutePath(), processedMat);
            }
        }
    }

    @FXML
    private void applyRotation() {
        if (originalMat != null) {
            try {
                double angle = Double.parseDouble(rotationAngleField.getText());

                Point center = new Point(originalMat.cols() / 2.0, originalMat.rows() / 2.0);
                Mat rotationMatrix = Imgproc.getRotationMatrix2D(center, angle, 1.0);

                Rect bbox = new RotatedRect(center, originalMat.size(), angle).boundingRect();
                rotationMatrix.put(0, 2, rotationMatrix.get(0, 2)[0] + bbox.width / 2.0 - center.x);
                rotationMatrix.put(1, 2, rotationMatrix.get(1, 2)[0] + bbox.height / 2.0 - center.y);

                processedMat = new Mat();

                int interpolation;
                String interpolationType = rotationInterpolationChoiceBox.getValue();
                if ("Bilinear".equals(interpolationType)) {
                    interpolation = Imgproc.INTER_LINEAR;
                } else {
                    interpolation = Imgproc.INTER_NEAREST;
                }

                Imgproc.warpAffine(originalMat, processedMat, rotationMatrix,
                        new Size(bbox.width, bbox.height),
                        interpolation);

                Stage rotationStage = new Stage();
                rotationStage.setTitle("Image Rotation Result");

                VBox root = new VBox(10);
                root.setAlignment(Pos.CENTER);
                root.setPadding(new Insets(10));

                Label titleLabel = new Label("Image Rotation Comparison");
                titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");


                HBox imageBox = new HBox(20);
                imageBox.setAlignment(Pos.CENTER);

                VBox originalBox = new VBox(5);
                originalBox.setAlignment(Pos.CENTER);
                ImageView originalView = new ImageView(matToImage(originalMat));
                originalView.setFitWidth(400);
                originalView.setPreserveRatio(true);
                Label originalLabel = new Label("Original Image");
                originalBox.getChildren().addAll(originalLabel, originalView);

                VBox rotatedBox = new VBox(5);
                rotatedBox.setAlignment(Pos.CENTER);
                ImageView rotatedView = new ImageView(matToImage(processedMat));
                rotatedView.setFitWidth(400);
                rotatedView.setPreserveRatio(true);
                Label rotatedLabel = new Label(String.format("Rotated Image (%.1f degrees)", angle));
                rotatedBox.getChildren().addAll(rotatedLabel, rotatedView);

                imageBox.getChildren().addAll(originalBox, rotatedBox);
                root.getChildren().addAll(titleLabel, imageBox);

                Scene scene = new Scene(root);
                rotationStage.setScene(scene);
                rotationStage.show();

                processedImageView.setImage(matToImage(processedMat));

                rotationAngleField.setText("");

            } catch (NumberFormatException e) {
                showAlert("Please enter a valid angle!");
            }
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyResize() {
        if (originalMat != null) {
            try {
                double scaleFactor = Double.parseDouble(scaleFactorField.getText());
                if (scaleFactor <= 0) {
                    showAlert("Scale factor must be positive!");
                    return;
                }

                processedMat = new Mat();
                Size newSize = new Size(originalMat.cols() * scaleFactor, originalMat.rows() * scaleFactor);

                int interpolation;
                String interpolationType = interpolationChoiceBox.getValue();
                if ("Bilinear".equals(interpolationType)) {
                    interpolation = Imgproc.INTER_LINEAR;
                } else {
                    interpolation = Imgproc.INTER_NEAREST;
                }

                Imgproc.resize(originalMat, processedMat, newSize, 0, 0, interpolation);


                Stage comparisonStage = new Stage();
                comparisonStage.setTitle("Size Comparison");

                double baseWidth = 300.0;
                double newWidth = baseWidth * scaleFactor;
                double aspectRatio = (double) originalMat.rows() / originalMat.cols();
                double baseHeight = baseWidth * aspectRatio;
                double newHeight = baseHeight * scaleFactor;

                VBox root = new VBox(10);
                root.setAlignment(Pos.CENTER);
                root.setPadding(new Insets(10));


                Label titleLabel = new Label("Image Size Comparison");
                titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

                HBox imageBox = new HBox(20);
                imageBox.setAlignment(Pos.CENTER);


                VBox originalBox = new VBox(5);
                originalBox.setAlignment(Pos.CENTER);
                ImageView originalView = new ImageView(matToImage(originalMat));
                originalView.setFitWidth(baseWidth);
                originalView.setFitHeight(baseHeight);
                originalView.setPreserveRatio(false);
                Label originalLabel = new Label(String.format("Original Size: %dx%d",
                        originalMat.cols(), originalMat.rows()));
                originalBox.getChildren().addAll(new Label("Original Image"), originalView, originalLabel);

                VBox resizedBox = new VBox(5);
                resizedBox.setAlignment(Pos.CENTER);
                ImageView resizedView = new ImageView(matToImage(processedMat));
                resizedView.setFitWidth(newWidth);
                resizedView.setFitHeight(newHeight);
                resizedView.setPreserveRatio(false);
                Label resizedLabel = new Label(String.format("New Size: %dx%d",
                        processedMat.cols(), processedMat.rows()));
                resizedBox.getChildren().addAll(new Label("Resized Image"), resizedView, resizedLabel);

                imageBox.getChildren().addAll(originalBox, resizedBox);

                root.getChildren().addAll(titleLabel, imageBox);

                double windowWidth = baseWidth + newWidth + 100;
                double windowHeight = Math.max(baseHeight, newHeight) + 100;

                Scene scene = new Scene(root, windowWidth, windowHeight);
                comparisonStage.setScene(scene);
                comparisonStage.show();

                scaleFactorField.setText("");

            } catch (NumberFormatException e) {
                showAlert("Please enter a valid number for scale factor!");
            }
        } else {
            showAlert("No image loaded!");
        }
    }


    private void browseImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.bmp"));
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            originalMat = Imgcodecs.imread(file.getAbsolutePath());
            originalImageView.setImage(matToImage(originalMat));
        }
    }

    @FXML
    private void clearOutput() {
        processedMat = null;
        processedImageView.setImage(null);
    }

    private Image matToImage(Mat mat) {
        MatOfByte buffer = new MatOfByte();
        Imgcodecs.imencode(".png", mat, buffer);
        return new Image(new ByteArrayInputStream(buffer.toArray()));
    }


    @FXML
    private void showHistogram() {
        if (originalMat != null) {
            showHistogramForImage(originalMat, "Original Image Histogram");
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void equalizeHistogram() {
        if (originalMat != null) {
            processedMat = new Mat();

            Mat grayMat = new Mat();
            Imgproc.cvtColor(originalMat, grayMat, Imgproc.COLOR_BGR2GRAY);

            Imgproc.equalizeHist(grayMat, processedMat);

            processedImageView.setImage(matToImage(processedMat));

            showHistogramForImage(processedMat, "Histogram of Equalized Image");
        } else {
            showAlert("No image loaded!");
        }
    }

    private void showHistogramForImage(Mat image, String title) {
        Stage histogramStage = new Stage();
        histogramStage.setTitle(title);

        Mat hist = new Mat();
        Imgproc.calcHist(java.util.Collections.singletonList(image), new MatOfInt(0), new Mat(), hist, new MatOfInt(256), new MatOfFloat(0, 256));

        Mat histImage = new Mat(300, 400, CvType.CV_8UC3, new Scalar(255, 255, 255));
        Core.normalize(hist, hist, 0, histImage.rows(), Core.NORM_MINMAX);

        int binWidth = (int) Math.round((double) histImage.cols() / 256);
        for (int i = 0; i < 256; i++) {
            int histHeight = (int) Math.round(hist.get(i, 0)[0]);
            Imgproc.rectangle(histImage,
                    new Point(i * binWidth, histImage.rows()),
                    new Point((i + 1) * binWidth, histImage.rows() - histHeight),
                    new Scalar(0, 0, 0),
                    Imgproc.FILLED);
        }

        ImageView histogramImageView = new ImageView(matToImage(histImage));
        VBox root = new VBox(histogramImageView);
        root.setStyle("-fx-padding: 20;");
        histogramStage.setScene(new Scene(root));
        histogramStage.show();
    }


    @FXML
    private void convertToBinary() {
        if (originalMat != null) {
            processedMat = new Mat();

            Mat grayMat = new Mat();
            Imgproc.cvtColor(originalMat, grayMat, Imgproc.COLOR_BGR2GRAY);

            double threshold = Imgproc.threshold(grayMat, processedMat, 0, 255, Imgproc.THRESH_BINARY | Imgproc.THRESH_OTSU);

            processedImageView.setImage(matToImage(processedMat));

        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyDilation() {
        if (originalMat != null) {
            processedMat = new Mat();

            Mat grayMat = new Mat();
            Imgproc.cvtColor(originalMat, grayMat, Imgproc.COLOR_BGR2GRAY);

            Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(5, 5));
            Imgproc.dilate(grayMat, processedMat, kernel);

            processedImageView.setImage(matToImage(processedMat));

        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyErosion() {
        if (originalMat != null) {
            processedMat = new Mat();

            Mat greyMat = new Mat();
            Imgproc.cvtColor(originalMat, greyMat, Imgproc.COLOR_BGR2GRAY);

            Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(5, 5));
            Imgproc.erode(originalMat, processedMat, kernel);

            processedImageView.setImage(matToImage(processedMat));
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyCannyEdge() {
        if (originalMat != null) {
            processedMat = new Mat();
            Imgproc.Canny(originalMat, processedMat, 100, 200);
            processedImageView.setImage(matToImage(processedMat));
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applySobelEdge() {
        if (originalMat != null) {
            processedMat = new Mat();
            Mat grad = new Mat();
            String direction = directionChoiceBox.getValue();

            if ("Horizontal".equals(direction)) {
                Imgproc.Sobel(originalMat, grad, CvType.CV_16S, 1, 0);
            } else if ("Vertical".equals(direction)) {
                Imgproc.Sobel(originalMat, grad, CvType.CV_16S, 0, 1);
            } else {
                Mat gradX = new Mat();
                Mat gradY = new Mat();
                Imgproc.Sobel(originalMat, gradX, CvType.CV_16S, 1, 0);
                Imgproc.Sobel(originalMat, gradY, CvType.CV_16S, 0, 1);
                Core.addWeighted(gradX, 0.5, gradY, 0.5, 0, grad);
            }

            Core.convertScaleAbs(grad, processedMat);
            processedImageView.setImage(matToImage(processedMat));
        }
    }

    @FXML
    private void applyLaplacianEdge() {
        if (originalMat != null) {
            processedMat = new Mat();
            Imgproc.Laplacian(originalMat, processedMat, CvType.CV_16S);
            Core.convertScaleAbs(processedMat, processedMat);
            processedImageView.setImage(matToImage(processedMat));
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyPrewittEdge() {
        if (originalMat != null) {
            processedMat = new Mat();
            Mat gradX = new Mat();
            Mat gradY = new Mat();

            Mat kernelX = new Mat(3, 3, CvType.CV_32F);
            kernelX.put(0, 0, -1, 0, 1, -1, 0, 1, -1, 0, 1);

            Mat kernelY = new Mat(3, 3, CvType.CV_32F);
            kernelY.put(0, 0, -1, -1, -1, 0, 0, 0, 1, 1, 1);

            Imgproc.filter2D(originalMat, gradX, CvType.CV_16S, kernelX);
            Imgproc.filter2D(originalMat, gradY, CvType.CV_16S, kernelY);

            String direction = directionChoiceBox.getValue();
            if ("Horizontal".equals(direction)) {
                Core.convertScaleAbs(gradX, processedMat);
            } else if ("Vertical".equals(direction)) {
                Core.convertScaleAbs(gradY, processedMat);
            } else {
                Core.convertScaleAbs(gradX, gradX);
                Core.convertScaleAbs(gradY, gradY);
                Core.addWeighted(gradX, 0.5, gradY, 0.5, 0, processedMat);
            }

            processedImageView.setImage(matToImage(processedMat));
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyLogEdge() {
        if (originalMat != null) {
            processedMat = new Mat();
            Mat gray = new Mat();
            Imgproc.cvtColor(originalMat, gray, Imgproc.COLOR_BGR2GRAY);
            Imgproc.GaussianBlur(gray, gray, new Size(3, 3), 0);
            Imgproc.Laplacian(gray, processedMat, CvType.CV_16S);
            Core.convertScaleAbs(processedMat, processedMat);
            processedImageView.setImage(matToImage(processedMat));
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyRobertsEdge() {
        if (originalMat != null) {
            processedMat = new Mat();
            Mat gradX = new Mat();
            Mat gradY = new Mat();

            Mat kernelX = new Mat(2, 2, CvType.CV_32F);
            kernelX.put(0, 0, 1, 0, 0, -1);

            Mat kernelY = new Mat(2, 2, CvType.CV_32F);
            kernelY.put(0, 0, 0, 1, -1, 0);

            Imgproc.filter2D(originalMat, gradX, CvType.CV_16S, kernelX);
            Imgproc.filter2D(originalMat, gradY, CvType.CV_16S, kernelY);

            String direction = directionChoiceBox.getValue();
            if ("Horizontal".equals(direction)) {
                Core.convertScaleAbs(gradX, processedMat);
            } else if ("Vertical".equals(direction)) {
                Core.convertScaleAbs(gradY, processedMat);
            } else {
                Core.convertScaleAbs(gradX, gradX);
                Core.convertScaleAbs(gradY, gradY);
                Core.addWeighted(gradX, 0.5, gradY, 0.5, 0, processedMat);
            }

            processedImageView.setImage(matToImage(processedMat));
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyGaussianFilter() {
        if (originalMat != null) {
            processedMat = new Mat();

            double sigma = 0;
            try {
                sigma = Double.parseDouble(sigmaTextField.getText());
            } catch (NumberFormatException e) {
                sigma = 1.0;
            }

            int kernelSize = 0;
            try {
                kernelSize = Integer.parseInt(kernelSizeField.getText());
                if (kernelSize % 2 == 0 || kernelSize < 1) {
                    showAlert("Kernel size must be a positive odd number!");
                    return;
                }
            } catch (NumberFormatException e) {
                kernelSize = 15;
            }

            Size kernelSizeObj = new Size(kernelSize, kernelSize);
            Imgproc.GaussianBlur(originalMat, processedMat, kernelSizeObj, sigma);

            processedImageView.setImage(matToImage(processedMat));

            sigmaTextField.setText("");
            kernelSizeField2.setText("");

        } else {
            showAlert("No image loaded!");
        }
    }


    @FXML
    private void applyMedianFilter() {
        if (originalMat != null) {
            try {
                int kernelSize = Integer.parseInt(kernelSizeField.getText());
                if (kernelSize % 2 == 0 || kernelSize < 1) {
                    showAlert("Kernel size must be a positive odd number!");
                    return;
                }

                processedMat = new Mat();
                Imgproc.medianBlur(originalMat, processedMat, kernelSize);

                processedImageView.setImage(matToImage(processedMat));

                kernelSizeField.setText("");

            } catch (NumberFormatException e) {
                showAlert("Please enter a valid integer for kernel size!");
            }
        } else {
            showAlert("No image loaded!");
        }
    }

    @FXML
    private void applyAverageFilter() {
        if (originalMat != null) {
            try {
                int kernelSize = Integer.parseInt(kernelSizeFieldAverage.getText());
                if (kernelSize % 2 == 0 || kernelSize < 1) {
                    showAlert("Kernel size must be a positive odd number!");
                    return;
                }

                processedMat = new Mat();
                Imgproc.blur(originalMat, processedMat, new Size(kernelSize, kernelSize));

                processedImageView.setImage(matToImage(processedMat));

                kernelSizeFieldAverage.setText("");

            } catch (NumberFormatException e) {
                showAlert("Please enter a valid integer for kernel size!");
            }
        } else {
            showAlert("No image loaded!");
        }
    }


    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void saveOutput() {
        Image processedImage = processedImageView.getImage();

        if (processedImage == null) {
            System.out.println("No processed image to save!");
            return;
        }

        PixelReader pixelReader = processedImage.getPixelReader();
        int width = (int) processedImage.getWidth();
        int height = (int) processedImage.getHeight();

        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int argb = pixelReader.getArgb(x, y);
                bufferedImage.setRGB(x, y, argb);
            }
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Processed Image");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG Files", "*.png"));
        File file = fileChooser.showSaveDialog(processedImageView.getScene().getWindow());

        if (file != null) {
            try {
                ImageIO.write(bufferedImage, "png", file);
                System.out.println("Image saved to: " + file.getAbsolutePath());
            } catch (IOException e) {
                System.err.println("Failed to save image: " + e.getMessage());
            }
        }
    }


}
